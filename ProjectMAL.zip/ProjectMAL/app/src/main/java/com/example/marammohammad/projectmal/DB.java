package com.example.marammohammad.projectmal;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

/**
 * Created by Maram Mohammad on 9/20/2016.
 */

public class DB  extends SQLiteOpenHelper {


    public static final String DATABASE_NAME = "DB.db";

    public static final String URL_LINK = "url_link";
    public static final String Description_CONTENT = "desc_content";
    public static final String RATE = "rate";
    public static final String RELEASE_DATE = "release_date";
    public static final String ORIGINAL_TITLE = "original_title";
    public static final String IMAGE_SRC = "image_src";
    public  static final String id="ID";

    private HashMap hp;

    public DB(Context context)
    {
        super(context, DATABASE_NAME, null, 1);
        //SQLiteDatabase mydatabase = openOrCreateDatabase(DATABASE_NAME,MODE_PRIVATE,null);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {


        db.execSQL(
                "create table favourites" +
                        "(id TEXT PRIMARY KEY NOT NULL ,desc_content TEXT ,rate TEXT," +
                        " release_date TEXT,original_title TEXT,image_src TEXT)");
/*
        db.execSQL(
                "create table trailers" +
                        "(movieID integer, name text,url_link text)");

        db.execSQL(
                "create table reviews" +
                        "(movieID integer, owner text,content text)");
*/
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS favourites");
        //db.execSQL("DROP TABLE IF EXISTS trailers");
        //db.execSQL("DROP TABLE IF EXISTS reviews");
        onCreate(db);
    }

    public boolean insert (Movie movie)
    {
        Log.d("maram123" ,"before insertion");
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put("id", Integer.toString(movie.getId()));
        contentValues.put("desc_content", movie.getOverview());
        contentValues.put("rate", movie.getVote_average());
        contentValues.put("release_date", movie.getReleaseDate());
        contentValues.put("original_title", movie.getOriginalTitle());
        contentValues.put("image_src", movie.getPosterPath());

        db.insert("favourites", null, contentValues);
        Log.d("maram123", "after insertion");


     /*  String exc=  "INSERT OR REPLACE INTO favourites (id,desc_content,rate,release_date,original_title,image_src)"+
                    "VALUES ("+Integer.toString(movie.getId())+","+
                               movie.getOverview()+","+
                               movie.getVote_average()+","+
                               movie.getReleaseDate()+","+
                               movie.getOriginalTitle()+","+
                               movie.getPosterPath()+");";
        db.execSQL(exc);*/

/*
        ArrayList<Movie.trails> tra = movie.getVideo();
        for(int i = 0 ; i < tra.size() ; i++){
            ContentValues contentValues1 = new ContentValues();
            contentValues1.put("name", tra.get(i).getName());
            contentValues1.put("url_link", tra.get(i).getUrl_link());
            contentValues1.put("movieID", movie.getId());
            db.insert("trailers", null, contentValues1);
        }

        ArrayList<Movie.reviews> rev = movie.getReview();
        for(int i = 0 ; i < rev.size() ; i++){
            ContentValues contentValues1 = new ContentValues();
            contentValues1.put("content", rev.get(i).getContent());
            contentValues1.put("owner", rev.get(i).getOwner());
            contentValues1.put("movieID", movie.getId());
            db.insert("reviews", null, contentValues1);
        }
*/
        return true;
    }

    public Integer delete (Integer id) {

        SQLiteDatabase db = this.getWritableDatabase();
      /*  int b1 = db.delete("trailers",
                "movieID = ? ", new String[] { Integer.toString(id) });
        int b2 = db.delete("reviews",
                "movieID = ? ", new String[] { Integer.toString(id) });
                */
        return db.delete("favourites",
                "id = ? ", new String[]{Integer.toString(id)});
    }


    public Movie getData(int id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery("select * from favourites where id=" + id + "", null);
        Movie mov=new Movie();

        mov.setOverview(res.getString(res.getColumnIndex("desc_content")));
        mov.setVote_average(res.getString(res.getColumnIndex("rate")));
        mov.setReleaseDate(res.getString(res.getColumnIndex("release_date")));
        mov.setOriginalTitle(res.getString(res.getColumnIndex("original_title")));
        mov.setPosterPath(res.getString(res.getColumnIndex("image_src")));
        mov.setId(Integer.parseInt(res.getString(res.getColumnIndex("id"))));
/*
        ArrayList<Movie.trails> tra = new ArrayList<Movie.trails>();
        Cursor res1 =  db.rawQuery("select * from trailers where movieID=" + id + "", null);
        res1.moveToFirst();

        while(res1.isAfterLast() == false){
            Movie.trails tr=new Movie.trails();

            tr.setName(res1.getString(res1.getColumnIndex("name")));
            tr.setUrl_link(res1.getString(res1.getColumnIndex("url_link")));
            tra.add(tr);
            res1.moveToNext();
        }

        ArrayList<Movie.reviews> rev = new ArrayList<Movie.reviews>();
        Cursor res2 =  db.rawQuery("select * from reviews where movieID=" + id + "", null);
        res2.moveToFirst();

        while(res2.isAfterLast() == false){
            Movie.reviews re=new Movie.reviews();

            re.setOwner(res2.getString(res2.getColumnIndex("owner")));
            re.setContent(res2.getString(res2.getColumnIndex("content")));
            rev.add(re);
            res2.moveToNext();
        }

        mov.setVideo(tra);
        mov.setReview(rev);

        res2.close();
        res1.close();
  */
        res.close();
        return mov;
    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db,"favourites");
        return numRows;
    }

    public ArrayList<Movie> getAllFavourites()
    {
        ArrayList<Movie> array_list = new ArrayList<Movie>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from favourites", null );
        res.moveToFirst();

        while(res.isAfterLast() == false){
            Movie mov=new Movie();

            mov.setOverview(res.getString(res.getColumnIndex("desc_content")));
            mov.setVote_average(res.getString(res.getColumnIndex("rate")));
            mov.setReleaseDate(res.getString(res.getColumnIndex("release_date")));
            mov.setOriginalTitle(res.getString(res.getColumnIndex("original_title")));
            mov.setPosterPath(res.getString(res.getColumnIndex("image_src")));
            String ID=res.getString(res.getColumnIndex("id"));
            mov.setId(Integer.parseInt(ID));
        /*
            ArrayList<Movie.trails> tra = new ArrayList<Movie.trails>();
            Cursor res1 =  db.rawQuery("select * from trailers where movieID=" + res.getColumnIndex("id") + "", null);
            res1.moveToFirst();

            while(res1.isAfterLast() == false){
                Movie.trails tr=new Movie.trails();

                tr.setName(res1.getString(res1.getColumnIndex("name")));
                tr.setUrl_link(res1.getString(res1.getColumnIndex("url_link")));
                tra.add(tr);
                res1.moveToNext();
            }

            ArrayList<Movie.reviews> rev = new ArrayList<Movie.reviews>();
            Cursor res2 =  db.rawQuery("select * from reviews where movieID=" + res.getColumnIndex("id") + "", null);
            res2.moveToFirst();

            while(res2.isAfterLast() == false){
                Movie.reviews re=new Movie.reviews();

                re.setOwner(res2.getString(res2.getColumnIndex("owner")));
                re.setContent(res2.getString(res2.getColumnIndex("content")));
                rev.add(re);
                res2.moveToNext();
            }

            mov.setVideo(tra);
            mov.setReview(rev);

            res2.close();
            res1.close();
*/

            array_list.add(mov);
            res.moveToNext();
        }

        res.close();
        return array_list;
    }
}
