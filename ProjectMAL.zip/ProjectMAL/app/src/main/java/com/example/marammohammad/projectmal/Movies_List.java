package com.example.marammohammad.projectmal;

/**
 * Created by Maram Mohammad on 8/8/2016.
 */

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.Dialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Layout;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;


import com.squareup.picasso.Picasso;

public class Movies_List extends Movie_Lists implements View.OnClickListener {
    String BY = "top_rated";
    ArrayList<Movie> movies;
    static ProgressDialog progress;
    GridView grid_view;
    static boolean visible = false;

    //---------------------tablte-------------------
    TextView t1;
    TextView t2;
    TextView t3;
    TextView t4;
    TextView t5;
    ImageView image;

    ImageButton addFav;
    ArrayList<Movie.trails> TheMovieTrailers;
    ArrayList<Movie.reviews> TheMovieReviews;
    Movie mov;
    DB dataBase = new DB(this);
    static Movie currentMovie=null;
    private static int index = 0;

    private class AsyncTask2 extends AsyncTask {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progress.show();
        }

        protected void onProgressUpdate(String... progress) {
            loading();
        }

        @Override
        protected ArrayList<Movie> doInBackground(Object... params) {
            try {
                //return searchIMDB((String) params[0]);
                dbGetResulte res = new dbGetResulte();
                return res.getMovies(BY);
            } catch (IOException e) {
                return null;
            }
        }

        @Override
        protected void onPostExecute(Object result) {
            visible = false;
            progress.dismiss();
            AdabterofMovies((ArrayList<Movie>) result);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_list);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.mytoolbar);
        setSupportActionBar(myToolbar);


        progress = new ProgressDialog(this);

        Bundle extras= getIntent().getExtras();
        BY = extras.getString("SortBy");
        visible = true;
        loading();
        getMovies();
    }



    @Override
    public void onSaveInstanceState(Bundle outState) {
        if(!visible)
            index = grid_view.getFirstVisiblePosition();
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onRestoreInstanceState(Bundle savedstate){
        super.onRestoreInstanceState(savedstate);
        View displayFrag = (View) findViewById(R.id.detailsFragment);
        if (displayFrag == null)
        grid_view = (GridView) findViewById(R.id.movie_list);
        else
            grid_view = (GridView) findViewById(R.id.movie_list_tab);

        if(index != 0)
            grid_view.setSelection(index);

        if (displayFrag != null&&currentMovie!=null) {
            mov=currentMovie;
            addFav = (ImageButton) findViewById(R.id.favoure);
            addFav.setOnClickListener(this);
            updateLayout(this);
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.exit) {
            Exit();
            return true;
        }
        else if (id==R.id.reload)
            reload();
        else if (id == R.id.sortRate){
            BY="top_rated";
            reload();}
         else if (id == R.id.sortPopular){
            BY="popular";
            reload(); }
        else if(id == R.id.fav){
            Intent intent = new Intent(getApplicationContext(), favourite.class);
            intent.putExtra("SortBy",BY);
            intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public void loading(){
        progress.setTitle("Loading");
        progress.setMessage("Wait while loading...");
    }

    public void getMovies(){
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected()) {
            visible = true;
            new AsyncTask2().execute();

        } else {
            visible = true;
            Dialogue.AlertDialog(this,"No NetworkConnection","Check your Netwotk connection and Try again");
        }
    }

    private void AdabterofMovies(ArrayList<Movie> Movies) {
        if(Movies != null){
            movies=Movies;
            List<Movie> movs = new ArrayList<Movie>();
            for (int i = 0; i < Movies.size(); i++) {
                movs.add(Movies.get(i));
            }
            View displayFrag = (View) findViewById(R.id.detailsFragment);
            CustomAdapter adapter = new CustomAdapter(this, R.layout.single, movs);
            if (displayFrag == null) {
                grid_view = (GridView) findViewById(R.id.movie_list);
                grid_view.setAdapter(adapter);
            }
            else {
                grid_view = (GridView) findViewById(R.id.movie_list_tab);
                grid_view.setAdapter(adapter);

            }



        }else{
            visible = true;
            Dialogue.AlertDialog(this,"Time out!!","Check your Netwotk connection and Try again");
        }
    }

    public void Exit() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
        finish();
        System.exit(0);
    }

    public void reload() {
        Intent intent = new Intent(getApplicationContext(), Movies_List.class);
        intent.putExtra("SortBy", BY);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        finish();
        startActivity(intent);
    }

    public void itemClicked(int position) {
       View displayFrag = (View) findViewById(R.id.detailsFragment);
        if (displayFrag == null) {
            Intent intent = new Intent(getApplicationContext(), Movie_Layout.class);
            intent.putExtra("Pos", position);
            intent.putExtra("SortBy", BY);
            intent.putExtra("Home","1");
            Movie obj=movies.get(position);
            intent.putExtra("MyClass",obj.buildString());
            intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
            startActivity(intent);
        } else {
            mov = movies.get(position);
            currentMovie=mov;
            addFav = (ImageButton) findViewById(R.id.favoure);
            addFav.setOnClickListener(this);
            updateLayout(this);
        }

    }
    public void loadTextViews(){
        t2 = (TextView) findViewById(R.id.desc_content);
        t3 = (TextView) findViewById(R.id.rate);
        t4 = (TextView) findViewById(R.id.release_date);
        t5 = (TextView) findViewById(R.id.original_title);
        image = (ImageView) findViewById(R.id.movie_single_image);
        ScrollView scrollView=(ScrollView)findViewById(R.id.scrollView);
        scrollView.setVisibility(View.VISIBLE);
    }

    public void updateLayout(Context context) {
        loadTextViews();
        dbGetResulte dbObject = new dbGetResulte();
        Picasso.with(context).load("http://image.tmdb.org/t/p/" + "w500" + mov.getPosterPath()).into((image));
        t2.setText(mov.getOverview());
        if (mov.getVote_average().length()>3)
            t3.setText( mov.getVote_average().substring(0, 3));
        else
            t3.setText(mov.getVote_average());
        t4.setText(mov.getReleaseDate());
        t5.setText(mov.getOriginalTitle());
        if (ifExists()==false) {
            addFav.setImageResource(R.drawable.favourite);
        }
        else{
            addFav.setImageResource(R.drawable.unfavourite);
        }
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected()) {
            new AsyncTask3().execute();
        } else {
            visible = true;
            Dialogue.AlertDialog(this,"No NetworkConnection","Check your Netwotk connection and Try again");
        }
    }

    //Open Youtube
    public void itemClickedYoutube(int position) {
        String url=TheMovieTrailers.get(position).getUrl_link();
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub

        if (ifExists()==false) {
            dataBase.insert(mov);
            addFav.setImageResource(R.drawable.unfavourite);
        }
        else {
            dataBase.delete(mov.getId());
            addFav.setImageResource(R.drawable.favourite);
        }

    }



    public boolean ifExists(){
        ArrayList<Movie> all=dataBase.getAllFavourites();
        for(Movie m:all){
            if(m.getId()==mov.getId())
                return true;
        }
        return  false;
    }

    private class AsyncTask3 extends AsyncTask {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progress.show();

        }


        protected void onProgressUpdate(String... progress) {
            loading();
        }

        @Override
        protected ArrayList<Movie.reviews> doInBackground(Object... params) {
            try {
                dbGetResulte res = new dbGetResulte();
                TheMovieTrailers = res.GetTrailers(String.valueOf(mov.getId()));
                TheMovieReviews = res.getReviews(String.valueOf(mov.getId()));
                return TheMovieReviews;
            } catch (IOException e) {
                return null;
            }
        }

        @Override
        protected void onPostExecute(Object result) {
            progress.dismiss();
            AdabterofReviwes(TheMovieReviews);
            AdabterofTrailers(TheMovieTrailers);
        }
    }
    private void AdabterofTrailers(ArrayList<Movie.trails> MovieTrailers) {


        if (MovieTrailers!=null){
            List<Movie.trails> trailer = new ArrayList<Movie.trails>();
            for (int i = 0; i < MovieTrailers.size(); i++) {
                trailer.add(MovieTrailers.get(i));
            }

            CustomAdapter2 adapter = new CustomAdapter2(this, R.layout.single_trailer, trailer);
            LinearLayout list_Tr=(LinearLayout)findViewById(R.id.list_trailers);
            final int adapterCount = adapter.getCount();
            for (int i = 0; i < adapterCount; i++) {
                View item = adapter.getView(i, null, null);
                list_Tr.addView(item);
            }


        }
        else{
            visible = true;
            Dialogue.AlertDialog(this,"Time out!!","Check your Netwotk connection and Try again");

        }
    }


    private void AdabterofReviwes(ArrayList<Movie.reviews> Rev) {

        if(Rev!=null){
            List<Movie.reviews> reviews= new ArrayList<Movie.reviews>();
            for (int i = 0; i < Rev.size(); i++) {
                reviews.add(Rev.get(i));
            }

            CustomAdapter3 adapter = new CustomAdapter3(this, R.layout.single_review, reviews);
            LinearLayout list_Revi=(LinearLayout)findViewById(R.id.list_reviews);
            final int adapterCount = adapter.getCount();
            for (int i = 0; i < adapterCount; i++) {
                View item = adapter.getView(i, null, null);
                list_Revi.addView(item);
            }
        }
        else{
            visible = true;
            Dialogue.AlertDialog(this,"Time out!!","Check your Netwotk connection and Try again");
        }
    }



}