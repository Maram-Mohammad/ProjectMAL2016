package com.example.marammohammad.projectmal;

        import android.util.Log;

        import org.json.JSONArray;
        import org.json.JSONException;
        import org.json.JSONObject;

        import java.io.BufferedReader;
        import java.io.IOException;
        import java.io.InputStream;
        import java.io.InputStreamReader;
        import java.io.Reader;
        import java.io.UnsupportedEncodingException;
        import java.net.HttpURLConnection;
        import java.net.URL;
        import java.util.ArrayList;

/**
 * Created by Maram Mohammad on 8/10/2016.
 */
public class dbGetResulte {

      String APIKey="";
    /*
      return movies depends on The Sort Type
     */
    public dbGetResulte(){}
    private  ArrayList<Movie>movies;



    public ArrayList<Movie> getMovies(String by)throws IOException {
        movies = searchIMDB(by);
        return movies;
    }


    private  ArrayList<Movie> searchIMDB(String by) throws IOException {
        // Create URL
        StringBuilder stBuilder = new StringBuilder(); 
        stBuilder.append("http://api.themoviedb.org/3/movie/"+by);
        stBuilder.append("?api_key=" +APIKey);
        URL url = new URL(stBuilder.toString());

        InputStream stream = null;
        try {
            // Establish a connection
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(1200000);
            conn.setConnectTimeout(1200000);
            conn.setRequestMethod("GET");
            conn.addRequestProperty("Accept", "application/json");
            conn.setDoInput(true);
            conn.connect();

            int responseCode = conn.getResponseCode();
            stream = conn.getInputStream();
            return parseResult(stringify(stream));
        } finally {
            if (stream != null) {
                stream.close();
            }
        }
    }



    public   ArrayList<Movie.trails> GetTrailers(String id) throws IOException {
        // Create URL
        StringBuilder stBuilder = new StringBuilder();
        stBuilder.append("http://api.themoviedb.org/3/movie/"+id+"/videos");
        stBuilder.append("?api_key=" + APIKey);
        URL url = new URL(stBuilder.toString());

        InputStream stream = null;
        try {
            // Establish a connection
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(1200000);
            conn.setConnectTimeout(1200000);
            conn.setRequestMethod("GET");
            conn.addRequestProperty("Accept", "application/json");
            conn.setDoInput(true);
            conn.connect();

            // Get The Result
            int responseCode = conn.getResponseCode();
            stream = conn.getInputStream();

            // Return The Result after Parsing it from json
            return parseTrailers(stringify(stream));
        } finally {
            if (stream != null) {
                stream.close();
            }
        }
    }








    public  ArrayList<Movie.reviews> getReviews(String id) throws IOException {
        // Create URL
        StringBuilder stBuilder = new StringBuilder();
        stBuilder.append("http://api.themoviedb.org/3/movie/"+id+"/reviews");
        stBuilder.append("?api_key=" + APIKey);
        URL url = new URL(stBuilder.toString());

        InputStream stream = null;
        try {
            // Establish a connection
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(1200000);
            conn.setConnectTimeout(1200000);
            conn.setRequestMethod("GET");
            conn.addRequestProperty("Accept", "application/json");
            conn.setDoInput(true);
            conn.connect();

            int responseCode = conn.getResponseCode();
            stream = conn.getInputStream();

            return parseReviews(stringify(stream));
        } finally {
            if (stream != null) {
                stream.close();
            }
        }
    }





    private ArrayList<Movie> parseResult(String result)  throws IOException{
        String streamAsString = result;
        ArrayList<Movie> results = new ArrayList<Movie>();
        try {
            JSONObject jsonObject = new JSONObject(streamAsString);
            JSONArray array = (JSONArray) jsonObject.get("results");
            for (int i = 0; i < array.length(); i++) {
                JSONObject jsonMovieObject = array.getJSONObject(i);
                Movie newMovie=new Movie();

                newMovie.setOriginalTitle(jsonMovieObject.getString("original_title"));
                newMovie.setPopularity(jsonMovieObject.getString("popularity"));
                newMovie.setBackdrop_path(jsonMovieObject.getString("backdrop_path"));
                newMovie.setOverview(jsonMovieObject.getString("overview"));
                newMovie.setPosterPath(jsonMovieObject.getString("poster_path"));
                newMovie.setReleaseDate(jsonMovieObject.getString("release_date"));
                newMovie.setVote_average(jsonMovieObject.getString("vote_average"));
                newMovie.setVote_count(jsonMovieObject.getString("vote_count"));
                newMovie.setId(Integer.parseInt(jsonMovieObject.getString("id")));


                results.add(newMovie);
            }

        } catch (JSONException e) {
            System.err.println(e);
        }

        return results;
    }



    private ArrayList<Movie.trails> parseTrailers(String result) {
        String streamAsString = result;
        String path1="https://www.youtube.com/watch?v=";
      
        ArrayList<Movie.trails> results = new ArrayList<Movie.trails>();
        try {
            JSONObject jsonObject = new JSONObject(streamAsString);
            JSONArray array = (JSONArray) jsonObject.get("results");
            for (int i = 0; i < array.length(); i++) {
                JSONObject jsonMovieObject = array.getJSONObject(i);
                Movie.trails newTrailer=new Movie.trails();

                if(jsonMovieObject.getString("site").equals("YouTube")
                        &&jsonMovieObject.getString("type").equals("Trailer") ){
                    newTrailer.setUrl_link(path1+jsonMovieObject.getString("key"));
                    newTrailer.setName(jsonMovieObject.getString("name"));
                    results.add(newTrailer);
                }

            }

        } catch (JSONException e) {
            System.err.println(e);
        }
        return results;
    }






    private ArrayList<Movie.reviews> parseReviews(String result) {
        String streamAsString = result;
  
        ArrayList<Movie.reviews> results = new ArrayList<Movie.reviews>();
        try {
            JSONObject jsonObject = new JSONObject(streamAsString);
            JSONArray array = (JSONArray) jsonObject.get("results");
            for (int i = 0; i < array.length(); i++) {
                JSONObject jsonMovieObject = array.getJSONObject(i);
                Movie.reviews newReviews=new Movie.reviews();


                newReviews.setOwner(jsonMovieObject.getString("author"));
                newReviews.setContent(jsonMovieObject.getString("content"));
                results.add(newReviews);


            }

        } catch (JSONException e) {
            System.err.println(e);
        }
        return results;
    }



    private  String stringify(InputStream stream) throws IOException, UnsupportedEncodingException {
        Reader reader = null;
        reader = new InputStreamReader(stream, "UTF-8");
        BufferedReader bufferedReader = new BufferedReader(reader);
        return bufferedReader.readLine();
    }

}
