package com.example.marammohammad.projectmal;


/**
 * Created by Maram Mohammad on 8/8/2016.
 */

import java.util.ArrayList;

public class Movie {


    public static class trails{

        String url_link;
        String name;

        public String getUrl_link() {
            return url_link;
        }

        public void setUrl_link(String url_link) {
            this.url_link = url_link;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }



        /*
  Convert Object into String
   */
        public String buildString() {
            String builder = "";
            builder += this.getName() + "||";
            builder += this.getUrl_link();
            return builder;
        }

        /*
        Convert String into Object
         */
        public static ArrayList<trails> buildObj(String s) {
            ArrayList builder=new ArrayList();

            String[] trail = s.split(">>");

            for(int i = 0;i<trail.length;i++){
                trails  Movtrailers = new trails();
                String[] arr = s.split("||");
                Movtrailers.setName(arr[0]);
                Movtrailers.setUrl_link(arr[1]);
                builder.add(Movtrailers);
            }




            return builder;
        }

    }

    public static class reviews{
        String owner;
        String content;

        public String getOwner() {
            return owner;
        }

        public void setOwner(String owner) {
            this.owner = owner;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }





        /*
  Convert Object into String
   */
        public String buildString() {
            String builder = "";
            builder += this.getOwner() + "<<";
            builder += this.getContent();
            return builder;
        }

        /*
        Convert String into Object
         */
        public static ArrayList<reviews> buildObj(String s) {
            ArrayList builder=new ArrayList();

            String[] review = s.split(">>");

            for(int i = 0;i<review.length;i++){
                trails  Movtreview = new trails();
                String[] arr = s.split("<<");
                Movtreview.setName(arr[0]);
                Movtreview.setUrl_link(arr[1]);
                builder.add(Movtreview);
            }
            return builder;
        }




    }

    private String originalTitle;
    private String releaseDate;
    private String posterPath;
    private ArrayList<trails> video;
    private ArrayList<reviews> review;
    private String overview;
    private int id;
    private String backdrop_path;
    private String popularity;
    private String vote_count;
    private String vote_average;




    public String getOriginalTitle() {
        return originalTitle;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public String getPosterPath() {
        return posterPath;
    }

    public ArrayList<trails> getVideo() {
        return video;
    }

    public ArrayList<reviews> getReview() {
        return review;
    }

    public String getOverview() {
        return overview;
    }

    public int getId() {
        return id;
    }

    public String getBackdrop_path() {
        return backdrop_path;
    }

    public String getPopularity() {
        return popularity;
    }

    public String getVote_count() {
        return vote_count;
    }

    public String getVote_average() {
        return vote_average;
    }




    public void setOriginalTitle(String originalTitle) {
        this.originalTitle = originalTitle;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public void setPosterPath(String posterPath) {
        this.posterPath = posterPath;
    }

    public void setVideo(ArrayList<trails> video) {
        this.video = video;
    }

    public void setReview(ArrayList<reviews> review) {
        this.review = review;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setBackdrop_path(String backdrop_path) {
        this.backdrop_path = backdrop_path;
    }

    public void setPopularity(String popularity) {
        this.popularity = popularity;
    }

    public void setVote_count(String vote_count) {
        this.vote_count = vote_count;
    }

    public void setVote_average(String vote_average) {
        this.vote_average = vote_average;
    }










    /*
    Convert Object into String
     */
    public String buildString() {
        String builder = "";
        builder += this.getOriginalTitle() + ",,";
        builder += this.getPosterPath() + ",,";
        builder += this.getReleaseDate() + ",,";
        builder += this.getOverview() + ",,";
        builder += this.getVote_average()+",,";
        builder += Integer.toString(this.getId());



        return builder;
    }

    /*
    Convert String into Object
     */
    public static Movie buildObj(String s) {
        Movie builder = new Movie();
        String[] movie = s.split(",,");
        builder.setOriginalTitle(movie[0]);
        builder.setPosterPath(movie[1]);
        builder.setReleaseDate(movie[2]);
        builder.setOverview(movie[3]);
        builder.setVote_average(movie[4]);
        builder.setId(Integer.parseInt(movie[5]));

       

        return builder;
    }
}




