package com.example.marammohammad.projectmal;

/**
 * Created by Maram Mohammad on 8/8/2016.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.List;

public class CustomAdapter2 extends ArrayAdapter<Movie.trails> {

    public Movie_Lists context;

    public CustomAdapter2(Context context, int resource, List<Movie.trails> items) {
        super(context, resource, items);
        this.context = (Movie_Lists)context;
    }


    public static  class Holder{
        Button button1 ;
    }
    @Override
    public View getView(final int position, View view, ViewGroup parent) {
        Movie.trails tra = (Movie.trails) getItem(position);
        Holder item;
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.single_trailer, null);
            item=new Holder();
            item.button1 = (Button)view.findViewById(R.id.url_link);
            view.setTag(item);
        }
        else {
            item = (Holder)view.getTag();
        }


        item.button1.setText(tra.getName());
        item.button1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                context.itemClickedYoutube(position);
            }
        });
        return view;
    }
}


