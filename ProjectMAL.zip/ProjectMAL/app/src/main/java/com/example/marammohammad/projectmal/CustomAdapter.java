package com.example.marammohammad.projectmal;

/**
 * Created by Maram Mohammad on 8/8/2016.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.List;

public class CustomAdapter extends ArrayAdapter<Movie> {

    public Movie_Lists context;

    public CustomAdapter(Context context, int resource, List<Movie> items) {
        super(context, resource, items);
        this.context = (Movie_Lists) context;
    }

    public static  class Holder{
        ImageView image1;

    }

    @Override
    public View getView(final int position, View view, ViewGroup parent) {
        // Get the data item for this position
        Movie mov = (Movie) getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view

        Holder item;
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.single, parent, false);
        }
        item=new Holder();
        item.image1 = (ImageView) view.findViewById(R.id.movie_image);
        String URL="http://image.tmdb.org/t/p/" + "w500" +mov.getPosterPath();
        Picasso.with(context).load(URL).placeholder(R.drawable.loading).fit().into(item.image1);
        item.image1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                context.itemClicked(position);
            }
        });

        return view;
    }

}


