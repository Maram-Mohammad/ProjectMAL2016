package com.example.marammohammad.projectmal;

/**
 * Created by Maram Mohammad on 8/8/2016.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.List;

public class CustomAdapter3 extends ArrayAdapter<Movie.reviews> {

    public Movie_Lists context;

    public CustomAdapter3(Context context, int resource, List<Movie.reviews> items) {
        super(context, resource, items);
        this.context = (Movie_Lists)context;
    }


    public static  class Holder{
        TextView name ;
        TextView content;

    }
    @Override
    public View getView(final int position, View view, ViewGroup parent) {
        Movie.reviews mov = (Movie.reviews) getItem(position);
        Holder item;
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.single_review, null);
            item=new Holder();
            item.name = (TextView)view.findViewById(R.id.reviewer_name);
            item.content = (TextView) view.findViewById(R.id.review_content);
            view.setTag(item);
        }
        else {
            item = (Holder)view.getTag();
        }

        item.name.setText(mov.getOwner());
        item.content.setText(mov.getContent());



        return view;
    }

}


