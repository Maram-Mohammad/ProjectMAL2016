package com.example.marammohammad.projectmal;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.style.TtsSpan;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Movie_Layout extends Movie_Lists implements OnClickListener {
    String BY="";
    Movie mov;

    TextView t1;
    TextView t2;
    TextView t3;
    TextView t4;
    TextView t5;
    ImageView image;
    ImageButton addFav;
    ProgressDialog progress;
    ArrayList<Movie.trails> TheMovieTrailers;
    ArrayList<Movie.reviews> TheMovieReviews;
    boolean visible ;
    int home;
    DB dataBase = new DB(this);

    private class AsyncTask2 extends AsyncTask {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progress.show();

        }


        protected void onProgressUpdate(String... progress) {
            loading();
        }

        @Override
        protected ArrayList<Movie.reviews> doInBackground(Object... params) {
            try {

                dbGetResulte res = new dbGetResulte();
                TheMovieTrailers = res.GetTrailers(String.valueOf(mov.getId()));
                TheMovieReviews = res.getReviews(String.valueOf(mov.getId()));
                return TheMovieReviews;
            } catch (IOException e) {
                return null;
            }
        }

        @Override
        protected void onPostExecute(Object result) {
            progress.dismiss();
            AdabterofReviwes(TheMovieReviews);
            AdabterofTrailers(TheMovieTrailers);
        }
    }


    public void loading(){

        progress.setTitle("Loading");
        progress.setMessage("Wait while loading...");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_layout);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar2);
        setSupportActionBar(myToolbar);

        progress = new ProgressDialog(this);
        loading();
        TheMovieReviews = new ArrayList<Movie.reviews>();
        TheMovieTrailers = new ArrayList<Movie.trails>();
        Bundle extras = getIntent().getExtras();
        BY = extras.getString("SortBy");
        home = Integer.parseInt(extras.getString("Home"));

        visible=false;
        mov=Movie.buildObj(extras.getString("MyClass"));
        addFav = (ImageButton) findViewById(R.id.favoure);
        addFav.setOnClickListener(this);
        updateLayout(this);
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        if (ifExists()==false) {
            dataBase.insert(mov);
            addFav.setImageResource(R.drawable.unfavourite);
        }
        else {
            dataBase.delete(mov.getId());
            addFav.setImageResource(R.drawable.favourite);
        }
    }
    public boolean ifExists(){
        ArrayList<Movie> all=dataBase.getAllFavourites();
        for(Movie m:all){
            if(m.getId()==mov.getId())
                return true;
        }
        return  false;
    }

    public void loadTextViews(){
        t2 = (TextView) findViewById(R.id.desc_content);
        t3 = (TextView) findViewById(R.id.rate);
        t4 = (TextView) findViewById(R.id.release_date);
        t5 = (TextView) findViewById(R.id.original_title);
        image = (ImageView) findViewById(R.id.movie_single_image);
        ScrollView scrollView=(ScrollView)findViewById(R.id.scrollView);
        scrollView.setVisibility(View.VISIBLE);
        scrollView.scrollTo(0, 0);
    }



    private void AdabterofTrailers(ArrayList<Movie.trails> MovieTrailers) {


        if (MovieTrailers!=null){
            List<Movie.trails> trailer = new ArrayList<Movie.trails>();
            for (int i = 0; i < MovieTrailers.size(); i++) {
                trailer.add(MovieTrailers.get(i));
            }

            CustomAdapter2 adapter = new CustomAdapter2(this, R.layout.single_trailer, trailer);
            LinearLayout list_Tr=(LinearLayout)findViewById(R.id.list_trailers);
            final int adapterCount = adapter.getCount();
            for (int i = 0; i < adapterCount; i++) {
                View item = adapter.getView(i, null, null);
                list_Tr.addView(item);
            }


        }
        else{
            visible = true;
            Dialogue.AlertDialog(this,"Time out!!","Check your Netwotk connection and Try again");

        }
    }

    private void AdabterofReviwes(ArrayList<Movie.reviews> Rev) {

        if(Rev!=null){
            List<Movie.reviews> reviews= new ArrayList<Movie.reviews>();
            for (int i = 0; i < Rev.size(); i++) {
                reviews.add(Rev.get(i));
            }

            CustomAdapter3 adapter = new CustomAdapter3(this, R.layout.single_review, reviews);
            LinearLayout list_Revi=(LinearLayout)findViewById(R.id.list_reviews);
            final int adapterCount = adapter.getCount();
            for (int i = 0; i < adapterCount; i++) {
                View item = adapter.getView(i, null, null);
                list_Revi.addView(item);
            }
        }
        else{
            visible = true;
            Dialogue.AlertDialog(this,"Time out!!","Check your Netwotk connection and Try again");
        }
    }

    public void updateLayout(Context context) {
        loadTextViews();
        dbGetResulte dbObject = new dbGetResulte();
        String URL="http://image.tmdb.org/t/p/" + "w500" + mov.getPosterPath();
        Picasso.with(context).load(URL).placeholder(R.drawable.loading).into((image));
        t2.setText(mov.getOverview());
        if (mov.getVote_average().length() > 3)
            t3.setText(mov.getVote_average().substring(0, 3));
        else
            t3.setText( mov.getVote_average());
        t4.setText(mov.getReleaseDate());
        t5.setText(mov.getOriginalTitle());

        if (ifExists()==false) {
            addFav.setImageResource(R.drawable.favourite);
        } else{
            addFav.setImageResource(R.drawable.unfavourite);
        }



        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected()) {
            new AsyncTask2().execute();
        } else {
            visible = true;
            Dialogue.AlertDialog(this,"No NetworkConnection","Check your Netwotk connection and Try again");
        }



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.movie_details, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.back) {
            if(home==1)
                onClickHome();
            else
                onClickBack();
            return true;
        }
        else if (id == R.id.home) {
            onClickHome();
            return true;
        }
        else if (id == R.id.reloadD) {
            reload();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void reload() {
        Intent intent = new Intent(getApplicationContext(), Movie_Layout.class);
        Log.d("Here1","dort");
        intent.putExtra("SortBy", BY);
        intent.putExtra("Home",Integer.toString(home));
        intent.putExtra("MyClass", mov.buildString());
        Log.d("here1", "Befroe set flag");
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        Log.d("Here3", "After setFlag");
        startActivity(intent);
    }
    public void onClickBack() {
        Intent intent = new Intent(this, favourite.class);
        intent.putExtra("SortBy", BY);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
    }
    public void onClickHome() {
        Intent intent = new Intent(this, Movies_List.class);
        intent.putExtra("SortBy", BY);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
    }


    @Override
    public void itemClicked(int position) {

    }

    //Open Youtube
    public void itemClickedYoutube(int position) {
        String url=TheMovieTrailers.get(position).getUrl_link();
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));

    }



}