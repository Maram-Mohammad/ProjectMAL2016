package com.example.marammohammad.projectmal;

import android.support.v7.app.ActionBarActivity;


public abstract class Movie_Lists extends ActionBarActivity {
    public abstract  void itemClicked(int position);
    public abstract void itemClickedYoutube(int position);
}
