package com.example.marammohammad.projectmal;

import android.app.Fragment;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.TextView;

import java.util.ArrayList;


public class ListFragment extends Fragment {

    String BY = "top_rated";
    ArrayList<Movie> movies;
    ProgressDialog progress;
    GridView grid_view;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.movie_list_content_tab,
                container, false);


        return view;
    }
}
